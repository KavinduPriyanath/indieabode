
import java.math.BigInteger;
public class DH{

    public static void main(String[] args){

        // chosen prime number
        BigInteger primeNumber = new BigInteger("33");  

        // chosen  primitive root of the prime number
        BigInteger primitiveRoot = new BigInteger("8");    
         

        // calculate the public key when private key is given
        if (args.length==1){
            BigInteger private_key=new BigInteger(args[0]);  // sender private key
            BigInteger public_key=primitiveRoot.modPow(private_key,primeNumber);  //sender public key  
            System.out.println("Public Key is "+ public_key.toString());
        }
        // calculate the session key when your private key and recipient public key is available
        else if(args.length==2){
            BigInteger private_key=new BigInteger(args[0]);  // sender private key
            BigInteger public_key=new BigInteger(args[1]);   // public key of the recipient
            BigInteger session_key=public_key.modPow(private_key,primeNumber);  // calculating the session key
            System.out.println("Session Key is "+ session_key.toString());
        }
        else{
            System.out.println("Invalid number of arguements"); // if arguements count is incorrect
        }
    }
}