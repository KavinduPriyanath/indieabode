1) Make sure 'module.txt' is in the same directory as "Algorithm.cpp"

2) Run "Algorithm.cpp"

3) Enter the string pattern you want to search for in the prompted cmd window

4) Press Enter...