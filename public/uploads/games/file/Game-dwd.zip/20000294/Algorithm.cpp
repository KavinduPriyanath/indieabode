#include <iostream>
#include <fstream>
#include <cctype>

using namespace std;

int main () {

  string pattern;
  string text;

  ifstream MyFile("modules.txt");       //Opening and reading from file

  int n;                                //length of the text
  int matchCount = 0;


  cout << "Enter your search: ";
  cin >> pattern;                       //prompting user to input string as pattern

  int m = pattern.length();             //length of the pattern

  while (getline(MyFile, text)) {         //read the file line by line
    n = text.length();

    //Algorithm for naive pattern searching
    for (int i=0; i<n-m+1; i++) {
      int j=0;

      for (j=0; j<m; j++) {

        if ((text[i+j] != (char) tolower(pattern[j])) && (text[i+j] != (char) toupper(pattern[j]))) {
          break;
        }

      }

      if (j==m) {
        cout << text << endl;   //printing out the matched entry from the file
        matchCount++;         //keeping track of matches count
      }

    }
  }

  cout << endl;
  cout << "Total No. Of Matches: " << matchCount << endl;

  MyFile.close();         //closing the file after operation is over

  return 0;
}
